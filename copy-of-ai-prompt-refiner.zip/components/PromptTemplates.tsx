
import React from 'react';
import { PROMPT_TEMPLATES } from '../constants';
import { SparklesIcon } from './icons/SparklesIcon';

interface PromptTemplatesProps {
    onSelectTemplate: (template: string) => void;
}

export const PromptTemplates: React.FC<PromptTemplatesProps> = ({ onSelectTemplate }) => {
    return (
        <div className="bg-brand-secondary p-6 rounded-lg shadow-lg">
            <div className="flex items-center gap-3 mb-4">
                <SparklesIcon className="w-6 h-6 text-brand-accent" />
                <h2 className="text-2xl font-semibold text-brand-light">Prompt Starters</h2>
            </div>
            <p className="text-sm text-brand-text mb-4">
                Not sure where to start? Click a template to load it into the input box.
            </p>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                {PROMPT_TEMPLATES.map((template) => (
                    <button
                        key={template.title}
                        onClick={() => onSelectTemplate(template.template)}
                        className="w-full text-left p-3 bg-brand-primary/50 hover:bg-brand-primary rounded-md transition-colors duration-200 focus:outline-none focus:ring-2 focus:ring-brand-accent"
                    >
                        <p className="text-sm font-medium text-brand-text">
                            {template.title}
                        </p>
                    </button>
                ))}
            </div>
        </div>
    );
};
