
import React from 'react';

export const SparklesIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
  <svg
    {...props}
    xmlns="http://www.w3.org/2000/svg"
    width="24"
    height="24"
    viewBox="0 0 24 24"
    fill="none"
    stroke="currentColor"
    strokeWidth="2"
    strokeLinecap="round"
    strokeLinejoin="round"
  >
    <path d="m12 3-1.5 3L7 7.5l3 1.5L12 12l1.5-3L17 7.5l-3-1.5z" />
    <path d="M5 13l1.5 3L10 17.5l-3 1.5L5 21l-1.5-3L0 16.5l3-1.5z" />
    <path d="M19 13l1.5 3L24 17.5l-3 1.5L19 21l-1.5-3L14 16.5l3-1.5z" />
  </svg>
);
