import React, { useState, useCallback } from 'react';
import type { RefinedPromptResponse } from '../types';
import { CopyIcon } from './icons/CopyIcon';
import { CheckIcon } from './icons/CheckIcon';
import { CompareIcon } from './icons/CompareIcon';

interface ComparisonViewProps {
  userInput: string;
  response: RefinedPromptResponse;
}

export const ComparisonView: React.FC<ComparisonViewProps> = ({ userInput, response }) => {
  const [copied, setCopied] = useState(false);

  const handleCopy = useCallback(() => {
    if (response.refinedPrompt) {
      navigator.clipboard.writeText(response.refinedPrompt);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    }
  }, [response.refinedPrompt]);

  const hasRefinedPrompt = response.refinedPrompt && response.refinedPrompt.trim() !== '';

  if (!hasRefinedPrompt) {
    return (
      <div className="bg-brand-secondary p-6 rounded-lg shadow-lg">
        <h2 className="text-2xl font-semibold text-brand-light mb-4">Clarification Needed</h2>
        <p className="text-brand-text bg-brand-primary p-4 rounded-md">{response.rationale}</p>
      </div>
    );
  }

  return (
    <div className="bg-brand-secondary p-6 rounded-lg shadow-lg">
      <div className="flex items-center gap-3 mb-4">
        <CompareIcon className="w-6 h-6 text-brand-accent" />
        <h2 className="text-2xl font-semibold text-brand-light">Prompt Comparison</h2>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {/* Original Prompt */}
        <div>
          <h3 className="text-lg font-semibold text-brand-light mb-2">Your Original Prompt</h3>
          <div className="bg-brand-primary p-4 rounded-md text-brand-text whitespace-pre-wrap font-mono text-sm h-full">
            {userInput}
          </div>
        </div>

        {/* Refined Prompt */}
        <div>
            <div className="flex justify-between items-center mb-2">
                <h3 className="text-lg font-semibold text-brand-light">AI-Refined Prompt</h3>
                 <button
                    onClick={handleCopy}
                    className="flex items-center gap-2 px-3 py-1.5 bg-brand-primary hover:bg-gray-700 text-sm font-medium rounded-md text-brand-text transition-colors duration-200"
                    title="Copy to clipboard"
                    >
                    {copied ? <CheckIcon className="w-4 h-4 text-green-400" /> : <CopyIcon className="w-4 h-4" />}
                    {copied ? 'Copied!' : 'Copy'}
                </button>
            </div>
            <div className="bg-brand-accent/10 p-4 rounded-md text-brand-text whitespace-pre-wrap font-mono text-sm border-2 border-brand-accent h-full shadow-lg shadow-brand-accent/10">
                {response.refinedPrompt}
            </div>
        </div>
      </div>
      
      <div className="mt-6">
        <h3 className="text-xl font-semibold text-brand-light mb-2">Rationale</h3>
        <p className="text-brand-text bg-brand-primary p-4 rounded-md">{response.rationale}</p>
      </div>

    </div>
  );
};
