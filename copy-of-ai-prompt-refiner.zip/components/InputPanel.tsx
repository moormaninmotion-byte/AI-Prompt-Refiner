
import React from 'react';
import type { ModelConfig } from '../types';
import { MagicWandIcon } from './icons/MagicWandIcon';
import { InfoIcon } from './icons/InfoIcon';
import { Tooltip } from './Tooltip';

interface InputPanelProps {
  userInput: string;
  setUserInput: (value: string) => void;
  onRefine: () => void;
  onClear: () => void;
  isLoading: boolean;
  isApiKeyMissing: boolean;
  config: ModelConfig;
  setConfig: (config: ModelConfig) => void;
  captchaNum1: number;
  captchaNum2: number;
  captchaAnswer: string;
  setCaptchaAnswer: (value: string) => void;
}

export const InputPanel: React.FC<InputPanelProps> = ({
  userInput,
  setUserInput,
  onRefine,
  onClear,
  isLoading,
  isApiKeyMissing,
  config,
  setConfig,
  captchaNum1,
  captchaNum2,
  captchaAnswer,
  setCaptchaAnswer,
}) => {
  const handleConfigChange = (param: keyof ModelConfig, value: string) => {
    const numValue = parseFloat(value);
    if (!isNaN(numValue)) {
      setConfig({ ...config, [param]: numValue });
    }
  };
  
  const handleTopKChange = (value: string) => {
    const intValue = parseInt(value, 10);
    if (!isNaN(intValue) && intValue >= 0) {
        setConfig({ ...config, topK: intValue });
    } else if (value === '') {
        setConfig({ ...config, topK: 0 });
    }
  }

  const isCaptchaCorrect = parseInt(captchaAnswer, 10) === captchaNum1 + captchaNum2;
  const isRefineDisabled = isLoading || !userInput.trim() || isApiKeyMissing || !isCaptchaCorrect;

  return (
    <div className="bg-brand-secondary p-6 rounded-lg shadow-lg h-full flex flex-col gap-6">
      {/* Step 1 */}
      <div>
        <h2 className="text-xl font-semibold text-brand-light mb-2"><span className="text-brand-accent">1.</span> Your Idea</h2>
        <p className="text-sm text-brand-text mb-4">
          Enter a concept, a question, or a challenge. Be as simple or as detailed as you like.
        </p>
        <textarea
          value={userInput}
          onChange={(e) => setUserInput(e.target.value)}
          placeholder="e.g., 'An image of a wise old owl reading a book in a library' or 'Explain quantum computing to a 5-year-old'"
          className="w-full h-48 bg-brand-primary border border-gray-600 rounded-md p-4 text-brand-text focus:ring-2 focus:ring-brand-accent focus:outline-none transition duration-200 resize-y disabled:opacity-50 disabled:cursor-not-allowed"
          disabled={isLoading}
        />
      </div>

      {/* Step 2 */}
      <div>
        <h2 className="text-xl font-semibold text-brand-light mb-4"><span className="text-brand-accent">2.</span> Adjust Parameters</h2>
        <div className="space-y-4">
          {/* Temperature */}
          <div>
            <div className="flex justify-between items-center mb-1">
              <div className="flex items-center gap-2">
                <label htmlFor="temperature" className="block text-sm font-medium text-brand-text">Temperature</label>
                <Tooltip text="Controls randomness. Higher values (e.g., 0.8) make the output more creative, while lower values (e.g., 0.2) make it more deterministic.">
                  <InfoIcon className="w-4 h-4 text-gray-400" />
                </Tooltip>
              </div>
              <span className="text-sm font-mono text-brand-accent bg-brand-primary px-2 py-0.5 rounded">{config.temperature.toFixed(2)}</span>
            </div>
            <input id="temperature" type="range" min="0" max="1" step="0.01" value={config.temperature} onChange={(e) => handleConfigChange('temperature', e.target.value)} disabled={isLoading} className="w-full h-2 bg-brand-primary rounded-lg appearance-none cursor-pointer accent-brand-accent disabled:opacity-50 disabled:cursor-not-allowed" />
          </div>
          {/* Top-P */}
          <div>
            <div className="flex justify-between items-center mb-1">
              <div className="flex items-center gap-2">
                <label htmlFor="topP" className="block text-sm font-medium text-brand-text">Top-P</label>
                <Tooltip text="Considers tokens based on their cumulative probability mass. A higher value (e.g., 0.95) allows for more diversity in the output.">
                  <InfoIcon className="w-4 h-4 text-gray-400" />
                </Tooltip>
              </div>
              <span className="text-sm font-mono text-brand-accent bg-brand-primary px-2 py-0.5 rounded">{config.topP.toFixed(2)}</span>
            </div>
            <input id="topP" type="range" min="0" max="1" step="0.01" value={config.topP} onChange={(e) => handleConfigChange('topP', e.target.value)} disabled={isLoading} className="w-full h-2 bg-brand-primary rounded-lg appearance-none cursor-pointer accent-brand-accent disabled:opacity-50 disabled:cursor-not-allowed" />
          </div>
          {/* Top-K */}
          <div>
            <div className="flex justify-between items-center mb-1">
              <div className="flex items-center gap-2">
                <label htmlFor="topK" className="block text-sm font-medium text-brand-text">Top-K</label>
                <Tooltip text="Considers only the top K most likely tokens at each step. A lower value restricts the model's choices, making it less random.">
                  <InfoIcon className="w-4 h-4 text-gray-400" />
                </Tooltip>
              </div>
              <input id="topK" type="number" min="0" step="1" value={config.topK} onChange={(e) => handleTopKChange(e.target.value)} disabled={isLoading} className="w-24 text-center bg-brand-primary border border-gray-600 rounded-md p-1 text-brand-text focus:ring-2 focus:ring-brand-accent focus:outline-none disabled:opacity-50 disabled:cursor-not-allowed" />
            </div>
          </div>
        </div>
      </div>
      
      {/* Step 3 */}
      <div className="mt-auto pt-6 border-t border-gray-700">
        <h2 className="text-xl font-semibold text-brand-light mb-4"><span className="text-brand-accent">3.</span> Refine</h2>
        
        <div className="mb-4">
            <label htmlFor="captcha" className="block text-sm font-medium text-brand-text mb-2">
                Security Check: What is {captchaNum1} + {captchaNum2}?
            </label>
            <input
                id="captcha"
                type="number"
                value={captchaAnswer}
                onChange={(e) => setCaptchaAnswer(e.target.value)}
                placeholder="Your answer"
                className="w-full sm:w-1/2 bg-brand-primary border border-gray-600 rounded-md p-2 text-brand-text focus:ring-2 focus:ring-brand-accent focus:outline-none transition duration-200 disabled:opacity-50 disabled:cursor-not-allowed"
                disabled={isLoading}
            />
        </div>

        <div className="flex flex-col sm:flex-row gap-4">
          <button onClick={onRefine} disabled={isRefineDisabled} className="flex-grow inline-flex items-center justify-center px-6 py-3 border border-transparent text-base font-medium rounded-md shadow-sm text-white bg-brand-accent hover:bg-indigo-500 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-brand-accent focus:ring-offset-brand-secondary disabled:bg-gray-500 disabled:cursor-not-allowed transition duration-200">
            {isLoading ? (
              <>
                <svg className="animate-spin -ml-1 mr-3 h-5 w-5 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24"><circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle><path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path></svg>
                Refining...
              </>
            ) : (
              <>
                <MagicWandIcon className="w-5 h-5 mr-2"/>
                Refine Prompt
              </>
            )}
          </button>
          <button onClick={onClear} disabled={isLoading} className="px-6 py-3 border border-gray-600 text-base font-medium rounded-md text-brand-text hover:bg-gray-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-gray-500 focus:ring-offset-brand-secondary transition duration-200 disabled:opacity-50 disabled:cursor-not-allowed">
            Clear
          </button>
        </div>
      </div>
    </div>
  );
};